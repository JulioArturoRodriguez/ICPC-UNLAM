def abreviar_palabra(palabra):
    if len(palabra) > 10:
        return palabra[0] + str(len(palabra) - 2) + palabra[-1]
    else:
        return palabra

n = int(input())
for _ in range(n):
    palabra = input()
    print(abreviar_palabra(palabra))
