s1, s2 = 4, 8
n, m = 4, 8
f1, f2 = 8, 4
print(s1==s2) # Comparador de igualdad
print(s1!=s2) # Comparador de distinto
print(n<m)    # Comparador menor
print(f2>f1)  # Comparador mayor
print(n*2<=m) # Comparador menor o igual
print(f1>=5)  # Comparador mayor o igual