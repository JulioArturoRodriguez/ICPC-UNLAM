weight=int(input("ingrese: "))
if weight%2==0 and weight > 2:
    print("Yes")
else:
    print("No")
