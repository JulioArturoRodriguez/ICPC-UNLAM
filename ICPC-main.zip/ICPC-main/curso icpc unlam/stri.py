s1, s2 = "hola ", "Mundo!"
print(s1+s2) #aca el + es la concatenacion
print(s1*5) # multiplicar por un entero repite el string
print(s1[1]) #accede a una letra de texto(la primera letra esta en posicion 0)
print(s2[0:3])# accede a una substring (un rango), con sintaxis inclusive-exclusive