import math

def numero_de_losas(n, m, a):
    losas_necesarias = math.ceil(n/a) * math.ceil(m/a)
    return losas_necesarias

n = int(input())
m = int(input())
a = int(input())

print(numero_de_losas(n, m, a))
