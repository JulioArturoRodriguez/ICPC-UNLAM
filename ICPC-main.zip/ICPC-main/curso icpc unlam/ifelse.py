num = int(input("Ingrese un numero: "))
if num>0:
  print("El número ingresado es positivo")
  print(2*num)
else:
  print("El número es negativo o 0")
  if num == 0:
    print("num es 0")
  else:
    print(num-1)
print("Esto viene después del if")