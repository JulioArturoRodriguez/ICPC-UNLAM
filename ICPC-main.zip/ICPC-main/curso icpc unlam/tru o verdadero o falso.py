# bool: valor de verdad(v o f)
v, f = True, False # true es verdadero, false es valor falso
print(v) # imprime true
print(f) # imprime false
print(v and f)  # El Y lógico, que da verdadero si ambas son verdaderas y sino da falso
print(v & f)    # Otra forma de escribir el Y lógico, son equivalentes.
print(v or f)   # El O inclusive lógico, que da verdadero si al menos una es verdadera
print(v | f)    # Otra forma de escribir el O inclusive lógico, son equivalentes.
print(v ^ f)    # El O exclusivo lógico, da verdadero si una y solo una es verdadera
