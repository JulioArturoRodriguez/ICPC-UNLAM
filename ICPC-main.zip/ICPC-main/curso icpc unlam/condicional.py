num = int(input("Ingrese un número: "))
if num>0:
  print("El número ingresado es positivo")