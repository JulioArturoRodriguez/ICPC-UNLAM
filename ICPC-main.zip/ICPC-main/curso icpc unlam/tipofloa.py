entero = int(input("Ingrese un entero: "))
print("El siguiente al entero ingresado es: ",entero+1)